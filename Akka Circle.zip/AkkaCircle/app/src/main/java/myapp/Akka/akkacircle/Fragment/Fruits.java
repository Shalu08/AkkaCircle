package myapp.Akka.akkacircle.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import myapp.Akka.akkacircle.Model.Images_list;
import myapp.Akka.akkacircle.R;
import myapp.Akka.akkacircle.Util.ListManager;



public class Fruits extends Fragment {

    private RecyclerView gridview, recyclerView;
    private ArrayList<Images_list> arrayList;

    private ListManager listManager, listgrid;
    public ImageView imageView,dailygrocery;
    private TextView textView;
    GridView gridView;
    static int pos;
    String[] values={"Plant","DietFood","Meat","Grocery","Fruit&Veg","Dairy","Pharmacy","Cafe"};
    int[] Images={R.drawable.house,R.drawable.dietfood,R.drawable.turkey,R.drawable.basket,R.drawable.harvest,R.drawable.milk,R.drawable.drug,R.drawable.cafe};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fruits,
                container, false);
    /**    recyclerView = view.findViewById(R.id.recyclerimages);
        arrayList = new ArrayList();

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));

        if(pos==0){
            listManager = new ListManager(Fruits.this, arrayList, R.layout.imagerecycler_cusstom, recyclerView, "");
        }

listManager.getAdapter().notifyDataSetChanged();**/
        return view;
    }


   /** @Override
    public void onBindView(ListManager.BaseViewHolder holder, int position, String for_what) {
        imageView.setImageResource(arrayList.get(position).getImag());
    }

    @Override
    public void ViewHolder(View itemView, String for_what) {
        imageView= (ImageView) itemView.findViewById(R.id.grocery);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }**/
}
