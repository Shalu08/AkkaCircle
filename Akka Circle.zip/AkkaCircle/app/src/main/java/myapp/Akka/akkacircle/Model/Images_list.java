package myapp.Akka.akkacircle.Model;

public class Images_list {

    public int getImag() {
        return Imag;
    }

    public void setImag(int imag) {
        Imag = imag;
    }

    private int Imag;

}
