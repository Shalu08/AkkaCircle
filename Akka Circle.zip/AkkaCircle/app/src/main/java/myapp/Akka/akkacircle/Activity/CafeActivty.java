package myapp.Akka.akkacircle.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;

import myapp.Akka.akkacircle.Model.Cafemodel;
import myapp.Akka.akkacircle.Model.Productlist;
import myapp.Akka.akkacircle.R;
import myapp.Akka.akkacircle.Util.ListManager;

public class CafeActivty extends AppCompatActivity implements ListManager.ListManagerInterface {
    private RecyclerView recyclerView;
    private ArrayList arrayList;

    private ListManager listManager;
    private ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafe_activty);
        recyclerView= findViewById(R.id.caferecycler);

        arrayList = new ArrayList();
        recyclerView.setLayoutManager(new GridLayoutManager(CafeActivty.this, 2));
        listManager = new ListManager(CafeActivty.this, arrayList, R.layout.cafecustomlist, recyclerView, "ABC");


        Cafemodel cafemodel=new Cafemodel();
        cafemodel.setImages(R.drawable.greentea);
        cafemodel.setPrice("Rs.80");
        cafemodel.setText("GreenTea");
        arrayList.add(cafemodel);
        Cafemodel cafemodel1=new Cafemodel();
        cafemodel1.setImages(R.drawable.greentea);
        cafemodel1.setPrice("Rs.80");
        cafemodel1.setText("GreenTea");
        arrayList.add(cafemodel1);
        Cafemodel cafemodel2=new Cafemodel();
        cafemodel2.setImages(R.drawable.greentea);
        cafemodel2.setPrice("Rs.80");
        cafemodel2.setText("GreenTea");
        arrayList.add(cafemodel2);
        Cafemodel cafemodel3=new Cafemodel();
        cafemodel3.setImages(R.drawable.greentea);
        cafemodel3.setPrice("Rs.80");
        cafemodel3.setText("GreenTea");
        arrayList.add(cafemodel3);
        Cafemodel cafemodel4=new Cafemodel();
        cafemodel4.setImages(R.drawable.greentea);
        cafemodel4.setPrice("Rs.80");
        cafemodel4.setText("GreenTea");
        arrayList.add(cafemodel4);
        listManager.getAdapter().notifyDataSetChanged();
    }

    @Override
    public void onBindView(ListManager.BaseViewHolder holder, int position, String for_what) {

    }

    @Override
    public void ViewHolder(View itemView, String for_what) {

    }
}
