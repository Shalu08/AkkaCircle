package myapp.Akka.akkacircle.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

import myapp.Akka.akkacircle.Fragment.Cart_Fragment;
import myapp.Akka.akkacircle.Fragment.Home_Fragment;
import myapp.Akka.akkacircle.Fragment.Meat_Fragment;
import myapp.Akka.akkacircle.Fragment.Search_Fragment;
import myapp.Akka.akkacircle.R;

public class Homepage extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener{
    private DrawerLayout dl;
    private ActionBarDrawerToggle t;
    private NavigationView nv;
    Toolbar toolbar;
    final Fragment fragment1= new Home_Fragment();
    final Fragment fragment2= new Search_Fragment();
    final Fragment fragment3= new Cart_Fragment();

    final FragmentManager fm = getSupportFragmentManager();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        loadFragment(new Home_Fragment());
       setupToolbar();
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this);

    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment fragment = null;


        switch (menuItem.getItemId()) {
            case R.id.menu_nearme:

                fragment = new Home_Fragment();
                return true;

            case R.id.menu_explor:
                fragment = new Search_Fragment();
                return true;

            case R.id.menu_cart:
                fragment = new Cart_Fragment();
                return true;

           case R.id.wallet:
                fragment = new Meat_Fragment();
                return true;
        }

        return loadFragment(fragment);
    }
    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;

    }
    private void setupToolbar(){
        dl = (DrawerLayout)findViewById(R.id.drawerlayout);
        toolbar=(Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(null);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        t=new ActionBarDrawerToggle(this,dl,toolbar,R.string.Open,R.string.Close);
        dl.addDrawerListener(t);
        t.syncState();
    }
}
